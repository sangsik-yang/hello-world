echo     Example how to start marking bouded boxes for training set Yolo v2


./yolo_mark x64/Release/data/img x64/Release/data/train.txt x64/Release/data/obj.names


pause
